-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 23, 2020 at 05:56 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lic`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(51) NOT NULL,
  `admin_password` varchar(512) NOT NULL,
  `admin_email` varchar(51) NOT NULL,
  `admin_mobile` varchar(31) NOT NULL,
  `admin_status` tinyint(4) NOT NULL DEFAULT 1,
  `admin_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_password`, `admin_email`, `admin_mobile`, `admin_status`, `admin_created`) VALUES
(1, 'Shiv', '$2y$10$6pFs4jRlTl23k81rcBPZ1eW5Xj77nHHUWnjL1SQQqJYU/RuQar6L2', 'rajeev.j@dibc.in', '8827263881', 1, '2019-12-29 15:47:35');

-- --------------------------------------------------------

--
-- Table structure for table `admin_menu`
--

CREATE TABLE `admin_menu` (
  `menu_id` int(11) NOT NULL,
  `menu_position` varchar(16) NOT NULL,
  `menu_parent` int(11) NOT NULL,
  `menu_link` varchar(64) NOT NULL,
  `menu_title` varchar(50) NOT NULL,
  `menu_type` varchar(16) NOT NULL,
  `menu_class` varchar(32) NOT NULL,
  `menu_onclick` varchar(64) NOT NULL,
  `menu_icon` varchar(32) NOT NULL,
  `menu_status` int(11) NOT NULL DEFAULT 1,
  `menu_admin` int(11) DEFAULT NULL,
  `menu_modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_menu`
--

INSERT INTO `admin_menu` (`menu_id`, `menu_position`, `menu_parent`, `menu_link`, `menu_title`, `menu_type`, `menu_class`, `menu_onclick`, `menu_icon`, `menu_status`, `menu_admin`, `menu_modified`) VALUES
(1, 'main', 0, '/admin/', 'Home', '', '', '', 'fa fa-home', 1, NULL, '2019-09-04 10:32:21'),
(2, 'main', 0, '#', 'Policy Holder', '', '', '', 'fa fa-users', 1, NULL, '2020-08-23 06:16:08'),
(3, 'main', 2, 'admin/clients', 'Policy Holder', '', '', '', '', 1, NULL, '2020-08-23 06:40:56');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL,
  `client_name` varchar(51) NOT NULL,
  `client_mobile` varchar(51) NOT NULL,
  `client_policy_no` varchar(51) NOT NULL,
  `client_dob` varchar(51) NOT NULL,
  `client_occupation` varchar(51) NOT NULL,
  `client_address` text NOT NULL,
  `client_premium_type` varchar(21) NOT NULL,
  `client_status` tinyint(4) NOT NULL DEFAULT 1,
  `client_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_id`, `client_name`, `client_mobile`, `client_policy_no`, `client_dob`, `client_occupation`, `client_address`, `client_premium_type`, `client_status`, `client_created`) VALUES
(1, 'Rajeev', '8827263881', 'Mumbai', 'AAA', 'DIBC', 'Malad', '61692', 1, '2019-12-26 13:32:29'),
(2, 'sadsad', '8888888888', '123456789', '2020-08-23', 'Teacher', 'SASASDSDSD', 'Jivan Lav', 1, '2020-08-23 15:01:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `admin_menu`
--
ALTER TABLE `admin_menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
