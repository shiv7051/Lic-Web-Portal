
$(document).on('submit','form',function(event){
  event.preventDefault();
  var $form = $(this),
  url = $form.attr("action");
      //console.log(url);
  $form.find('.form-response').remove();
  //$form.prepend('<div class="form-response">Processing...</div>');
  $form.find('[type="submit"]').each(function(){
		$(this).attr('disabled','disabled').attr('text',$(this).text()).text('Processing').addClass('loading');
	})

  // data=$form.serializeArray();
  // data.push({name: "authkey", value: window.authkey});
  formdata = new FormData($form[0]);

  for (var value of formdata.values()) {
   console.log(value);
 }

  $.ajax({
    type: "POST",
    url: url,
    data: formdata,
		processData: false,
		contentType: false,
    success: function(data){
        $form.find('.form-response').remove();
        $form.find('[type="submit"]').each(function(){
			$(this).prop('disabled','').text($(this).attr('text')).removeClass('loading');
		})
		$form.prepend('<div class="formresponse success">'+data.message+'</div>');
		$('html, body').animate({
			scrollTop: $form.offset().top-200
		}, 1000);
		setTimeout(function(){
			$form.find('.formresponse').fadeOut(1000, function() { $(this).remove(); });
		}, 5000);

		if(typeof data.reload != 'undefined'){
			setTimeout(function(){
				if($form.closest('.dibcWinUI-wrap').length > 0){
				  var dibcWinUIid = $form.closest('.dibcWinUI-wrap').find('.dibcWinUI-title').text().trim().replace(/[^a-zA-Z 0-9]+/g, '');
				  if(dibcWinUIid){
					$.dibcwinui(dibcWinUIid).reload();
				  }
				} else {
				  location.reload();
				}
			}, parseInt(data.reload)*1000);
		}
		if(typeof data.redirect != 'undefined'){
			setTimeout(function(){
				window.location.href = window.baseurl+data.redirect;
			}, 1000);
		}

    },
    error: function(jqXHR, textStatus, errorThrown) {

        $form.find('.form-response').remove();
        $form.prepend('<div class="form-response text-danger">'+jqXHR.responseJSON.error+'</div>');
    },
    dataType: 'json'
  });
});

/*Delete function */
$(document).on('click','.delete_data',function(e){
    e.preventDefault();
   $(this).addClass('confirm_delete').text("Confirm Cancel").removeClass('.delete_data');
});
$(document).on('click','.confirm_delete',function(e){
    e.preventDefault();
    var deletedrow = $(this).closest('tr');
    var gid = $(this).attr('source');
    var link = $(this).attr('href');
$.ajax({
    type: "post",
    url:link,
    cache: false,
    datatype: 'json',
    success: function(data){
      $(deletedrow).hide('slow');
      $(gid).hide('slow');
      $(document).find('.modal').modal('hide');
    }
    });
});
/*JS FOR ADD ROW*/

$(document).find('.row-container').each(function(){
  $(this).find('.row').each(function(i){
    if(i){
      console.log(i);
      $(this).append('<div class="col-md-1"><label>Delete</label></br><span class="remove-new-row btn btn-danger">x</span></div>');
    }
  });
});
$(document).on('click','.row-container .add-new-row', function(){
  //console.log("click");
  var row = $(this).closest('.row-container').find('.row').first().html();
  var rowclass = $(this).closest('.row-container').find('.row').first().attr('class');
  $('<div class="'+rowclass+'">'+row+'</div>').insertBefore($(this));
  $(this).closest('.row-container').find('.row').last().append('<div class="col-md-1"><label>Delete</label><span class="remove-new-row btn btn-danger">x</span></div>');
  $(this).closest('.row-container').find('.row').last().find('input:not(.repeat),select:not(.repeat)').val('');
  $(document).find('.order_form .client').trigger('change');
});
$(document).on('click','.row-container .remove-new-row', function(){
  var rowcontainer = $(this).closest('.row-container');
  $(this).closest('.row').remove();
  $(rowcontainer).find('.row').first().find('select').trigger('change');
});

/*Dependent drop down group discount*/
$(document).on('change', '.order_form .client', function(e){
  var cid = $(this).closest('.order_form').find('.client').val();
  if(cid){
    $(this).closest('.order_form').find('.order-items').removeClass('hidden');
  } else {
    $(this).closest('.order_form').find('.order-items').addClass('hidden');
  }
});

  $(document).on('change', '.order_form .product', function(e){
    var productRow = $(this).closest('.row');
      var pid= $(this).closest('.row').find('.product').val();
    console.log(pid);
    if(!pid){
      return false;
    }
    $.ajax({
      type: "post",
      url:window.baseurl+"index.php/admin_api/product_detail/"+pid,
      cache: false,
      datatype: 'json',
      success: function(data){
           $(productRow).find('.category').val(data.product.cate_title);
           $(productRow).find('.code').val(data.product.prod_code);
           $(productRow).find('.prod_weight').val(data.product.prod_weight);
        }
      });
  });
