$(document).ready(function(){
    setTimeout(function(){

      $('.data-table').each(function(){
        // $(this).DataTable();
        $(document).find('.data-table').DataTable({
    dom: 'Bfrtip',
    buttons: [
          {
            extend: 'colvis',
            text: 'Select Columns',
          },
          'excel',
          'pdf',
          'print'
        ]
    });
      });

    },1000);

  $('.gn-submenu').hide();
  $(document).find('.gn-submenu').closest('li').on('click',function(e){
    $(this).find('.gn-submenu').toggle('slide')
  });
  // $('.signin-form').niceScroll();
  $(document).find('.filter-one').each(function(){ $(this).trigger('change'); });
  // $(document).find('.dibc-filter-table').each(function(){
  //   var opts = {};
  //   $(this).find('th').each(function(){
  //     if($(this).text()){
  //       opts[$(this).text()] = $(this).index();
  //     }
  //   });
  //   var optHtml = '<select multiple class="dibc-filter-table-select-col">';
  //   $.each(opts, function(i,j){
  //     optHtml += '<option value="'+j+'" selected>'+i+'</option>';
  //   })
  //   optHtml += '</select>';
  //   $(this).find('th').eq(0).append(optHtml);
  //   $(this).find('.dibc-filter-table-select-col').select2();
  // });
  $('.dropdown-menu label').click(function(e) {
      e.stopPropagation();
  });
  $(document).find('table.dataTable').DataTable({
    dom: 'Bfrtip',
    buttons: [
      {
        extend: 'colvis',
        text: 'Select Columns',
        // columnText: function ( dt, idx, title ) {
        //     return (idx+1)+': '+title;
        // }
      },
      'copy', 'excel', 'pdf', 'print'
    ]
});

});

 $(document).on('click','.dibc-filter-form .dibc-filter-submit', function(){
   $ff = $(this).closest('.dibc-filter-form');
   var type = [];
   $ff.find('.filter-type:checked').each(function(){
     type.push($(this).val());
   });
   var vendor = [];
   $ff.find('.filter-vendor:checked').each(function(){
     vendor.push($(this).val());
   });
   var url = "https://" + window.location.hostname + window.location.pathname;
   url += '?type='+type.join('-');
   url += '&vendor='+vendor.join('-');
   window.location.href = url;
 });

function apiRequest($form, url, data, type="POST") {
      $.ajax({
        type: type,
        url: url,
        data: data,
        processData: false,
        contentType: false,
        headers: {
            'jalsaAdminAuthkey':window.jalsaAdminAuthkey,
        },
        success: function(data){
          console.log('success');
          $form.find('[type="submit"]').each(function(){
						$(this).prop('disabled','').text($(this).attr('text')).removeClass('loading');
					});
            $.notify({
                    icon: 'fa fa-check-circle',
                    message: data.message,
                  },{
                      type: 'success',
                      timer: 1000,
                  });
            if(typeof data.keepModelOpen == 'undefined'){
              $('.modal').modal('hide');
              var dibcWinUIid = $form.closest('.dibcWinUI-wrap').find('.dibcWinUI-title').text().trim();
              if(dibcWinUIid){
                $.dibcwinui(dibcWinUIid).close();
              }

            }
            if(typeof data.resetForm != 'undefined'){
    			     $form[0].reset();
               $form.find('.media').empty();
             }
            $('a[href="'+window.pushstateurl+'"]').trigger('click');
            if(typeof data.reload != 'undefined'){
							setTimeout(function(){
								location.reload();
							}, parseInt(data.reload)*1000);
						}
            if(typeof data.redirect != 'undefined'){
							setTimeout(function(){
								window.location.href = window.baseurl+data.redirect;
							}, 1000);
						}
            if(typeof data.atitle != 'undefined'){
							$('a[href="'+url+'"]').text(data.atitle);
						}
            if(typeof data.ahref != 'undefined'){
							$('a[href="'+url+'"]').attr('href',data.ahref);
						}
            if(typeof data.newTab != 'undefined'){
              setTimeout(function(){
                var win = window.open(data.newTab, '_blank');
              });
            }
            if(typeof data.popup != 'undefined'){
              setTimeout(function(){
                if(data.popup.indexOf('whatsapp.com')){
                  title = 'Whatsapp';
                } else if (data.popup.indexOf('JalsaGroup')){
                  title = 'JalsaGroup.com';
                } else {
                  title = explode('/',url)[2];
                }
                var win = window.open(data.popup, title, 'menubar=no, location=no, toolbar=no, scrollbars=yes, height=640, width=720, fullscreen=no');

                if (win) {
                    win.focus();
                } else {
                    alert('Please allow popups for this website');
                }
              }, 1000);
            }
            if(typeof data.run != 'undefined'){
               eval(data.run);
             }
            if(typeof data.customAttr != 'undefined'){
              if(typeof data.customAttr == "object"){
                $.each(data.customAttr, function(i,j){
                  $(i).attr(j.key,j.val);
                })
              }
             }
            if(typeof data.inputVal != 'undefined'){
              if(typeof data.inputVal == "object"){
                $.each(data.inputVal, function(i,j){
                  $('[name='+i+']').val(j);
                })
              }
             }
            if(typeof data.setInWindow != 'undefined'){
              if(typeof data.setInWindow == "object"){
                $.each(data.setInWindow, function(i,j){
                  window[i]=j;
                })
              }
             }
            if(typeof data.domText != 'undefined'){
              if(typeof data.domText == "object"){
                $.each(data.domText, function(i,j){
                  $(i).text(j);
                })
              }
             }
            if(typeof data.domHtml != 'undefined'){
              if(typeof data.domHtml == "object"){
                $.each(data.domHtml, function(i,j){
                  $(i).text(j);
                })
              }
             }
        },
        error:  function(jqXHR, textStatus){
          if(typeof jqXHR.responseJSON != 'undefined'){
            if(typeof jqXHR.responseJSON.error != 'undefined'){
              $.notify({
                      icon: 'fa fa-info-circle',
                      message: jqXHR.responseJSON.error
                    },{
                        type: 'danger',
                        timer: 7000
                    });
            }
            if(typeof jqXHR.responseJSON.warning != 'undefined'){
              $.notify({
                      icon: 'fa fa-question-circle',
                      message: jqXHR.responseJSON.warning
                    },{
                        type: 'warning',
                        timer: 7000
                    });
            }
          }else {
            $.notify({
                    icon: 'fa fa-info-circle',
                    message: "System error. Please contact DIBC Team."
                  },{
                      type: 'danger',
                      timer: 7000
                  });
          }
          if(textStatus === 'timeout') {
            $.notify({
                    icon: 'pe-7s-attention',
                    message: "Unable to get a response from the server. Please check your internet connection, refresh the page and try again."
                  },{
                      type: 'warning',
                      timer: 7000
                  });
          }
          $form.find('[type="submit"]').each(function(){
						$(this).prop('disabled','').text($(this).attr('text')).removeClass('loading');
					})
        },
      timeout:60000,
      dataType: 'json'
    });
}

$(document).on('click','.form-submit',function(){
  $(this).closest('form').trigger('submit');
});
$(document).on('submit','form:not("[no-jquery]")',function(event){
  event.preventDefault();
  var $form = $( this ),
  url = $form.attr( "action" );
  $form.find('[type="submit"]').each(function(){
    $(this).attr('disabled','disabled').attr('text',$(this).text()).text('Processing').addClass('loading');
  })
  var data = new FormData($(this)[0]);
  apiRequest($form, url, data);
});
// $(document).on('click','a[href]:not("[no-jquery]")',function(event){
//   var url=$(this).attr('href');
//   $form = $(this);


//     if(
//       url.toLowerCase().startsWith('dibc_admin_api')
//       || url.toLowerCase().startsWith(window.baseurl.toLowerCase()+'dibc_admin_api')
//       || url.toLowerCase().startsWith('admin_api')
//       || url.toLowerCase().startsWith(window.baseurl.toLowerCase()+'admin_api')
//       || url.toLowerCase().startsWith('manager_api')
//       || url.toLowerCase().startsWith(window.baseurl.toLowerCase()+'manager_api')
//       || url.toLowerCase().startsWith('engineer_api')
//       || url.toLowerCase().startsWith(window.baseurl.toLowerCase()+'engineer_api')
//       || url.toLowerCase().startsWith('vendor_api')
//       || url.toLowerCase().startsWith(window.baseurl.toLowerCase()+'vendor_api')
//     ){
//       event.preventDefault();
//       //var url = $(this).attr('href');
//       // $(this).attr('href','#');
//       // $(this).attr('data-href',url);


//       /*Confirm API action */
//       if($(this).hasClass('confirm-action')){
//          $(this).addClass('action-confirmed').text("Are you sure?").removeClass('confirm-action');
//       } else {
//         $form = $(this);
//         var link = $(this).attr('href');
//         apiRequest($form, link, '', 'GET');
//       }

//     } else if(
//       url.toLowerCase().startsWith('dibc_admin')
//       || url.toLowerCase().startsWith(window.baseurl.toLowerCase()+'dibc_admin')
//       || url.toLowerCase().startsWith('admin')
//       || url.toLowerCase().startsWith(window.baseurl.toLowerCase()+'admin')
//       || url.toLowerCase().startsWith('manager')
//       || url.toLowerCase().startsWith(window.baseurl.toLowerCase()+'manager')
//       || url.toLowerCase().startsWith('engineer')
//       || url.toLowerCase().startsWith(window.baseurl.toLowerCase()+'engineer')
//       || url.toLowerCase().startsWith('vendor')
//       || url.toLowerCase().startsWith(window.baseurl.toLowerCase()+'vendor')
//     ){
//     event.preventDefault();
//     var title = $(this).attr('title');
//     if(typeof title == "undefined"){
//       title = $(this).text();
//     }
//       $.ajax({
//         type: "get",
//         url: url,
//         success: function(data){
//           if($form.closest('.page-container').length>0){
//               $form.closest('.page-container').html($(data).filter('.page-container').html());
//               $('.dibcWinUI-loaded').animate({ scrollTop: 0 }, 1000);
//               if(!window.lodedInWindow){
//                 if (typeof (history.pushState) != "undefined") {
//                   var obj = { Title: title, Url: url };
//                   history.pushState(obj, obj.Title, obj.Url);
//                 } else {
//                   console.log("Browser does not support HTML5.");
//                 }
//               }
//           } else if($form.closest('#main-content').length>0){
//             $(document).find('.modal').each(function(){
//               if(typeof $(this).modal === "function"){
//                 $(this).modal('hide');
//               }
//             });
//             $(document).find('.modal-backdrop').remove();
//             $(document).find('#main-content').html(data);
//             if(!window.lodedInWindow){
//               if (typeof (history.pushState) != "undefined") {
//                 var obj = { Title: title, Url: url };
//                 history.pushState(obj, obj.Title, obj.Url);
//               } else {
//                 console.log("Browser does not support HTML5.");
//               }
//             }
//           } else {
//             window.location.href = url
//           }
//         },
//         error: function(jqXHR, textStatus, errorThrown) {
//           //  console.log(jqXHR);
//         }
//       });

//   } else {
//     console.log('aaaa'+url.toLowerCase()+':::'+window.baseurl.toLowerCase()+'dibc_admin')
//   }

// });

/*JS FOR ADD ROW*/

$(document).find('.row-container').each(function(){
  $(this).find('.row').each(function(i){
    if(i){
      console.log(i);
      $(this).append('<div class="col-md-1"><label>Delete</label></br><span class="remove-new-row btn btn-danger">x</span></div>');
    }
  });
});
$(document).on('click','.row-container .add-new-row', function(){
  //console.log("click");
  var row = $(this).closest('.row-container').find('.row').first().html();
  var rowclass = $(this).closest('.row-container').find('.row').first().attr('class');
  $('<div class="'+rowclass+'">'+row+'</div>').insertBefore($(this));
  $(this).closest('.row-container').find('.row').last().append('<div class="col-md-1"><label>Delete</label></br><span class="remove-new-row btn btn-danger">x</span></div>');
  $(this).closest('.row-container').find('.row').last().find('input,select').val('');
});
$(document).on('click','.row-container .remove-new-row', function(){
  var rowcontainer = $(this).closest('.row-container');
  $(this).closest('.row').remove();
  $(rowcontainer).find('.row').first().find('select').trigger('change');
});
/*function for filert*/
$(document).on('click','.user-filter-options .filter-users', function(){
  var urlPart = $(this).attr('filter-url');
  var audi='',audisec='';
  var ain = [];
  $(document).find('.audi-sec-filters.user-filter-options').find('.user-filter-audi:checked').each(function(){
    ain.push($(this).val());
  });
  if(ain != null && ain.length > 0){
    var audi= ain.join('-');
  } else {
    audi = "all";
  }
  var asin = [];
  $(document).find('.audi-sec-filters.user-filter-options').find('.user-filter-audisec:checked').each(function(){
    asin.push($(this).val());
  });
  if(asin != null && asin.length > 0){
    var audisec= asin.join('-');
  } else {
    audisec = "all";
  }
  var pln = [];
  $(document).find('.plan-filters.user-filter-options').find('.user-filter-plan:checked').each(function(){
    pln.push($(this).val());
  });
  if(pln != null && pln.length > 0){
    var plan= pln.join('-');
  } else {
    plan = "all";
  }

  window.location.href = window.baseurl+urlPart+audi+'/'+audisec+'/'+plan;
});
/*Function of dependency*/
$(document).on('change','#eventsubmit .dramatype',function(){
    var x= $(this).val();
    var y = $(this).closest('#eventsubmit').find('.drama');
  console.log(x);
      $.ajax({
        type: "post",
        url:"dramatype/"+x,
        cache: false,
        datatype: 'json',
        success: function(data){
         data = JSON.parse(data);
         console.log(data);
         $.each(data,function(c,d){
            $(y).append('<option value="0" style="display:none">\
            Select Drama</option><option value="'+d.drama_id+'">'+d.drama_title+'</option>');

          })
        }
    });
});
/*Delete function */
$(document).on('click','.delete_data',function(e){
    e.preventDefault();
   $(this).addClass('confirm_delete').text("Confirm Remove").removeClass('.delete_data');
});
$(document).on('click','.confirm_delete',function(e){
    e.preventDefault();
    $form = $(this)
    var deletedrow = $(this).closest('tr');
    var link = $(this).attr('href');
    //console.log("ok");
    apiRequest($form, link, '', 'GET');
})
function removeRow(deletedrow){
  $(deletedrow).hide('slow');
}
$(document).on('change', '.filter-one', function(){
  if($(this).attr('type') == "radio"){
    var filterClass = $(this).attr('dibc-filter-class');
    var filterTarget = $(this).attr('dibc-filter-target');
  } else {
    var filterClass = $(this).find(':selected').attr('dibc-filter-class');
    var filterTarget = $(this).find(':selected').attr('dibc-filter-target');
  }
  $(document).find(filterTarget).each(function(){
    if($(this).hasClass(filterClass)){
      $(this).show();
    } else {
      $(this).hide();
      if($(this).is(':selected')){
        $(this).closest('select').prop('selectedIndex',0);
      }
      if($(this).is(':checked')){
        $(this).prop('checked', false);
        $(document).find(filterTarget+":visible").prop('checked', true);
      }
    }
  });
});

$(document).on('change','.checkbox-toggle-group .checkbox-toggle-pair',function(){
  if($(this).prop('checked')){
    $(this).closest('.checkbox-toggle-group').find('.checkbox-toggle-pair').not(this).prop('checked',false);
  } else {
    $(this).closest('.checkbox-toggle-group').find('.checkbox-toggle-pair').not(this).prop('checked',true);
  }
})


function popupWindow(title,data,url){
var win = window.open(url, '_blank');
if (win) {
    //Browser has allowed it to be opened
    win.focus();
} else {
    //Browser has blocked it
    alert('Please allow popups for this website');
}
  // var example = new jPopup({
	// 	title: "",
	// 	content: data,
	// 	closeButton: "true",
  //   overlay:false,
	// 	draggable: true,
  //   keyClose: [27],
  //   freeze: true,
	// 	buttons: [{
	// 		text: "+",
	// 		value: url,
	// 		"class": "openNewTab"
	// 	}]
	// });
  // example.open();
  // title = title.trim();
  // var id = title; //parseInt(5*Math.random());
  // console.log(id);
  // $.dibcwinui({
  //   type: 'ajax',
  //   title: title,
  //   content: url,
  //   overlay: false,
  //   icons: ['refresh','min', 'max', 'close'],
  //   id: id
  // });
}

// $(document).on('click', '.openNewTab', function(e){
//   var url = $(this).attr('data-value');
//   var win = window.open(url, '_blank');
//   if (win) {
//     //Browser has allowed it to be opened
//     win.focus();
//     $(this).closest('.jp_popup').find('.jp_popup_close').trigger('click');
//   } else {
//     //Browser has blocked it
//     alert('Please allow popups for this website');
//   }
// });

$(document).on('click', '.accounts_entry_done', function(e){
  //e.preventDefault();
  var planId = $(this).attr('planid');
  url = window.baseurl+'admin/api/accounts_api/accounts_entry/'+planId+'/';
  if($(this).is(":checked")){
    url+='1';
  } else {
    url+='0';
  }
  apiRequest($(this), url, false, "GET");
})

$(document).on('click', '.send_whatsapp_form .send_whatsapp', function(){
  var mob = $(this).closest('.send_whatsapp_form').find('.mobile').val();
  var msg = $(this).closest('.send_whatsapp_form').find('.message').val();
  var url = "https://wa.me/91"+mob+"?text="+encodeURIComponent(msg);
  var win = window.open(url, 'WhatsApp', 'menubar=no, location=no, toolbar=no, scrollbars=yes, height=720, width=720, fullscreen=no');
  if (win) {
      win.focus();
  } else {
      alert('Please allow popups for this website');
  }
});

  $(document).on('click', '.audi-layout-seat:not(.unavailable)', function(e){
    seat = $(this).attr('row')+'-'+$(this).attr('seat');
    if($.inArray(seat,window.seats)<0){
      window.seats.push(seat);
    } else {
      window.seats.splice($.inArray(seat,window.seats), 1);
    }
    $(this).toggleClass('selected').addClass('selected-seat-'+seat);
    if(window.seats.length>window.members){
      var seat = window.seats.shift();
      var rc = seat.split('+');
      $(document).find('.audi-layout-seat.selected-seat-'+seat).removeClass('selected selected-seat-'+seat);
    }
    if(window.seats.length>0){
      $(document).find('.all-selected-seats').text(window.seats.join(', '));
      $(document).find('[name="bsu-seats"]').val(window.seats.join(', '));
      $(document).find('.all-selected-seats-label').text('Click to book seats');
    } else {
      $(document).find('.all-selected-seats').text('');
      $(document).find('.all-selected-seats-label').text('');
      $(document).find('[name="bsu-seats"]').val('');
    }
    //apiRequest($(this), url, false, "GET");
  });

  $(document).on('click','#bsu-change',function(){
    var id=$(this).closest('.input-group').find('.bsu-id').val();
    var mobile=$(this).closest('.input-group').find('.bsu-mobile').val();
    mobile = parseInt(mobile.replace('/+/g', '').replace('/ /g', ''));
    if(mobile != 0 && mobile.toString().length != 10){
      alert('please enter a valid 10 digit mobile number')
    } else {
      var url = window.baseurl+window.usertype+'_api/member/'+window.e_id +'/'+window.es_id +'/'+id+'/'+mobile;
      if($(this).hasClass('bsu-change-alt')){
        url = window.baseurl+window.usertype+'_api/member_alt/'+window.audi_id+'/'+window.plan_id+'/'+id+'/'+mobile;
      }
      apiRequest($(this), url, '', "GET");
    }
  });
  $(document).on('click','.update-bsu-sect', function(){
    window.seats = [];
    $(document).find('.audi-layout-seat').removeClass('selected');
    // $(document).find('.audi-layout-seat[class^="selected-"]').each(function(){
    //   var cs = $(this).attr('class').split(' ');
    //   $.each(cs, function(i,j){
    //     console.log(j);
    //     if(j.match("^selected-")){
    //       $(document).find('.'+j).removeClass(j);
    //     }
    //   })
    // })
    $(document).find('.booking-user-info').show();
    $(document).find('.no-user-booking-action').hide();
    $(document).find('.all-selected-seats').text('');
    $(document).find('.all-selected-seats-label').text('');
    $(document).find('[name="bsu-seats"]').val('');
    var s = $(document).find('[name="bsu-sect"]').val();

    $(document).find('.audi-layout-seat:not(.do-not-touch)').addClass('unavailable not-in-section');
    $(document).find('.audi-layout-seat[section="'+s+'"]:not(.do-not-touch)').removeClass('unavailable');

  });
  $(window).keydown(function(evt) {
    if (evt.which == 17) { // ctrl
      window.ctrlPressed = true;

    }
  }).keyup(function(evt) {
    if (evt.which == 17) { // ctrl
      window.ctrlPressed = false;
    }
  });
  $(document).on('click','.dibcWinUI-loaded:not(clicked)',function(){
    window.clickedWindow = this;
    $(this).addClass('clicked');
    $(this).dragScroll({});
    if(window.ctrlPressed){
      document.getSelection().removeAllRanges();
    }
  });

  // $(document).on('scroll','.dibcWinUI-loaded', function(){
  //   var sticky = $('.sticky'),
  //   scroll = $(window).scrollTop();
  //   console.log('scroll');
  //   if (scroll >= 100) sticky.addClass('fixed');
  //   else sticky.removeClass('fixed');
  // });
  $(document).on('change', '.quantity', function(e){
    var price=$(this).closest('.row').find('.price').val();
    var qty=$(this).closest('.row').find('.quantity').val();
    var total=parseInt(price*qty);
    $(this).closest('.row').find('.total').val(total);
  });

/*Dependent drop down*/
  $(document).on('change', '.asset_assignment .client', function(e){
    var x = $(this).val();
    window.clientid = x;
    var y = $(this).closest('.asset_assignment').find('.contract');
    var z = $(this).closest('.asset_assignment').find('.spoc');
    y.empty().append('<option value="0" selected disabled>Select Contract</option>');
    z.empty().append('<option value="0" selected disabled>Select Spoc</option>');
    $.ajax({
      type: "post",
      url:window.baseurl+window.usertype+"_api/contract/"+x,
      cache: false,
      datatype: 'json',
      success: function(data){
       // data = JSON.parse(data);
       // console.log(data)
         $.each(data.contracts,function(c,d){
            $(y).append('<option value="'+d.contract_id+'">'+d.contract_title+"-"+d.contract_start_date+" to "+d.contract_end_date+'</option>');
          });
          $(y).select2("destroy");
         $.each(data.spocs,function(c,d){
            $(z).append('<option value="'+d.spoc_id+'">'+d.spoc_name+'</option>');
          })
          $(z).select2("destroy");
          setTimeout(function(){
            $(y).select2();
            $(z).select2();
          },500);
        }
    });
  });

  $(document).on('change', '.return-assets .contract, .return-assets .spoc', function(e){
    var client = $('.return-assets .client').val();
    if(!client){
      client = window.clientid;
    }
    var contract = $('.return-assets .contract').val();
    var spoc = $('.return-assets .spoc').val();
    var y = $(this).closest('.return-assets').find('.assigned-assets');
    y.empty();
    $.ajax({
      type: "post",
      url:window.baseurl+window.usertype+"_api/get_assigned_assets/"+client+'/'+contract+'/'+spoc+'/',
      cache: false,
      datatype: 'json',
      success: function(data){
       // data = JSON.parse(data);
       // console.log(data)
       if(data.assets){
        $(document).find('.assigned-assets').select2('destroy');
         $.each(data.assets,function(c,d){
           $(y).append('<option value="'+d.asset_id+'">'+d.nielsen_device_no+"-"+d.type+" to "+d.make_title+'</option>');
         });
         setTimeout(function(){
           $(document).find('.assigned-assets').select2();
         },500);
       }
        }
    });
  });
  /*Dependent drop down*/
    $(document).on('change', '.asset_form .device-make, .asset_form .device-type', function(e){
      var x = $(this).closest('.asset_form').find('.device-make').val();
      var y = $(this).closest('.asset_form').find('.device-type').val();
      var z = $(this).closest('.asset_form').find('.modelno');
      z.empty().append('<option value="0" selected disabled>Select Model No</option>');
      $.ajax({
        type: "post",
        url:window.baseurl+window.usertype+"_api/makeasset/"+x+'/'+y,
        cache: false,
        datatype: 'json',
        success: function(data){
         // data = JSON.parse(data);
         // console.log(data)
           $.each(data.modelno,function(c,d){
              $(z).append('<option value="'+d.model_id+'">'+d.model_no+'</option>');
            })
          }
      });
    });
/*date frequency calculation-12-10-2019*/
$(document).on('change', '.sudvey_form .currentdate', function(e){
  var currentdate=$(this).val();
  var today = new Date(currentdate);
  var yearval=parseInt($(this).attr('year'));

var year = today.getFullYear();
var month = today.getMonth();
var day = today.getDate();
var c = new Date(year + yearval, month, day);
console.log(c.toISOString().substring(0, 10));
// var year = c.getFullYear();
// var month = c.getMonth();
// var day = c.getDate();
//   var duedate=year+'-'+month+'-'+day;
duedate = c.toISOString().substring(0, 10);
  $(this).closest('tr').find('.duedate').val(duedate);
});
