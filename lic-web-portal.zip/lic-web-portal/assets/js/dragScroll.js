(function ($) {
    $.fn.dragScroll = function (options) {
        /* Mouse dragg scroll */
        var x, y, top, left, down;
        var $scrollArea = $(this);
        var ctrlPressed = false;
        $(window).keydown(function(evt) {
          if (evt.which == 17) { // ctrl
            ctrlPressed = true;
            $(document).find('.dibcWinUI-loaded').css( 'cursor', 'grab' );
          }
        }).keyup(function(evt) {
          if (evt.which == 17) { // ctrl
            ctrlPressed = false;
            $(document).find('.dibcWinUI-loaded').css( 'cursor', 'default' );
          }
        });
        if(ctrlPressed){
          $($scrollArea).attr("onselectstart", "return false;");   // Disable text selection in IE8
        }

        $($scrollArea).mousedown(function (e) {
            if(typeof options.limitTo == "object") {
                for(var i = 0; i < options.limitTo.length; i++) {
                    if($(e.target).hasClass(options.limitTo[i])) {
                        doMousedown(e);
                    }
                }
            } else {
                doMousedown(e);
            }
        });
        $($scrollArea).mouseleave(function (e) {
          down = false;
            if(ctrlPressed){
              $(document).find('.dibcWinUI-loaded').css( 'cursor', 'grab' );
            }
        });
        $("body").mousemove(function (e) {
            if (down && ctrlPressed) {
                var newX = e.pageX;
                var newY = e.pageY;
                $($scrollArea).scrollTop(top - newY + y);
                $($scrollArea).scrollLeft(left - newX + x);
            }
        });
        $("body").mouseup(function (e) {
          down = false;
          if(ctrlPressed){
            $(document).find('.dibcWinUI-loaded').css( 'cursor', 'grab' );
          }
        });

        function doMousedown(e) {
          down = true;
            if(ctrlPressed){
              e.preventDefault();
              $(document).find('.dibcWinUI-loaded').css( 'cursor', 'grabbing' );
              x = e.pageX;
              y = e.pageY;
              top = $($scrollArea).scrollTop();
              left = $($scrollArea).scrollLeft();
            }

        }
    };
})(jQuery);
