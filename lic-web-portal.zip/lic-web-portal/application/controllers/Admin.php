<?php
defined('BASEPATH') OR exit('Access-Control-Allow-Origins');

class Admin extends CI_controller {
	  function __construct()  {
      parent::__construct();
			$this->load->model('admin_model');
			$auth=$this->session->userdata('DIBCAuthkey');
			if(@$auth['admin']){
				 $admin =$this->encryption->decrypt($auth['admin']);
				 if($admin){
					 $this->admin= $this->admin_model->admin_data($admin);
				 }
			} else {
				redirect('/web/login');
			}
		}
	public function load_header(){
		if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] == "XMLHttpRequest"){
		} else {
			$data['admindata']= $this->admin;
			$data['mainMenu']=$this->admin_model->menuList();
			$this->load->view('includes/header',$data);
		}
	}
	public function load_footer(){
		if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] == "XMLHttpRequest"){
		} else {
			$this->load->view('includes/footer');
		}
	}
public function index(){
	$this->load_header();
	$this->load->view('includes/dashboard');
	$this->load_footer();
}
public function change_password(){
	$this->load_header();
	$this->load->view('change_password');
	$this->load_footer();
}
public function clients(){
	$data['clients']=$this->admin_model->get_clients();
	$this->load_header();
	$this->load->view('client_list',$data);
	$this->load_footer();
}
public function new_client(){
	$this->load_header();
	$this->load->view('new_client');
	$this->load_footer();
}
public function edit_client($id){
	$data['client']=$this->admin_model->get_client($id);
	$this->load_header();
	$this->load->view('client_edit',$data);
	$this->load_footer();
}

}
?>
