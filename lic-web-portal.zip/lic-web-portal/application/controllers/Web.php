<?php
defined('BASEPATH') OR exit('Access-Control-Allow-Origins');

class Web extends CI_controller {
	  function __construct()  {
      parent::__construct();
			$this->load->model('admin_model');
		}

	public function login(){
		$this->session->unset_userdata('DIBCAuthkey');
		$this->load->view('login');
	}
	public function login_post(){
	  	$this->form_validation->set_rules('username','Username','trim|xss_clean|required');
	  	$this->form_validation->set_rules('password','Password','trim|xss_clean|required');
			if($this->form_validation->run()== FALSE){
				redirect('/web/login?error=Invalid inputs');
	      exit;
				}
			$adminname=$this->input->post('username');
			$password=$this->input->post('password');
	    $admin=$this->admin_model->get_admin($adminname,$password);
	    if($admin == false){
	     	redirect('/web/login?error=incorrect username or password');
	    }
			$pwd_hash=$admin->admin_password;
			if(password_verify($password,$pwd_hash)){
				$auth=array('admin'=>$this->encryption->encrypt($admin->admin_id));
				$this->session->set_userdata('DIBCAuthkey',$auth);
				redirect('/admin');
			}else {
			 redirect('/web/login');
			}
	}
}
?>
