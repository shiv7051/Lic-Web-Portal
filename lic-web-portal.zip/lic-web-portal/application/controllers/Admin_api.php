<?php
header("Access-Control-Allow-Origin: *");
require(APPPATH . '/libraries/REST_Controller.php');
class Admin_api extends REST_Controller {
  function __construct()  {
    parent::__construct();
    $this->load->model('admin_model');
    $auth=$this->session->userdata('DIBCAuthkey');
    if(@$auth['admin']){
       $admin =$this->encryption->decrypt($auth['admin']);
       if($admin){
         $this->admin= $this->admin_model->admin_data($admin);
       }
    } else {
      redirect('/web/login');
    }
  }
  public function change_password_post(){
    $this->form_validation->set_rules('old_password','user Password','trim|required|xss_clean');
    $this->form_validation->set_rules('new_password','New Password','trim|required|xss_clean');
    $this->form_validation->set_rules('conf_password','Confirm Password','required|matches[new_password]');
    if($this->form_validation->run()== FALSE){
      $response['error']=validation_errors();
      $this->response($response,REST_Controller::HTTP_NOT_ACCEPTABLE);
      exit;
    }
      $data=array(
                  'admin_id'=>$this->admin->admin_id,
                  'admin_old_pwd'=>$this->input->post('old_password'),
                  'admin_password'=>$this->input->post('new_password')
            );

      $result=$this->admin_model->change_password($data);
      if($result == false){
        $response['error'] = "Password not Changed";
        $this->response($response,REST_Controller::HTTP_NOT_ACCEPTABLE);
      }
      else {
        $response['message']="Password Changed";
        $response['redirect']="admin/";
        $this->response($response,200);
        }
  }
public function add_client_post(){
    $this->form_validation->set_rules('policy_no','Policy Number','trim|xss_clean|required|exact_length[9]');
    $this->form_validation->set_rules('name','Name','trim|xss_clean|required');
    if($this->input->post('clientid')){
      $this->form_validation->set_rules('mobile','Mobile','trim|xss_clean|exact_length[10]|is_unique[clients.client_mobile]',array('is_unique' => 'The Mobile number is already registered'));
    }
    $this->form_validation->set_rules('mobile','Mobile','trim|xss_clean|exact_length[10]');
    $this->form_validation->set_rules('dob','DOB','trim|xss_clean|required');
    $this->form_validation->set_rules('occupation','Occupation','trim|xss_clean|required');
    $this->form_validation->set_rules('premium_type','Premium Number','trim|xss_clean|required');
    $this->form_validation->set_rules('address','Address','trim|xss_clean|required');
      if($this->form_validation->run()== FALSE){
        $response['error']=validation_errors();
        $this->response($response,REST_Controller::HTTP_NOT_ACCEPTABLE);
        exit;
      }
    $clientdata=array(
          'client_name'=>$this->input->post('name'),
          'client_mobile'=>$this->input->post('mobile'),
          'client_policy_no'=>$this->input->post('policy_no'),
          'client_dob'=>$this->input->post('dob'),
          'client_occupation'=>$this->input->post('occupation'),
          'client_premium_type'=>$this->input->post('premium_type'),
          'client_address'=>$this->input->post('address')
    );
    $clientid=$this->input->post('clientid');
   if($clientid){
      $result=$this->admin_model->client_update($clientdata,$clientid);
      if ($result === FALSE) {
            $response['error'] = array("message"=>"Error");
            $this->response($response,REST_Controller::HTTP_NOT_ACCEPTABLE);
      } else {
          $response['message']="Client is updated";
          $response['redirect']="admin/clients";
          $this->response($response,200);
    }
    }else {
      $result=$this->admin_model->client_insert($clientdata);
    }
    if ($result === FALSE) {
          $response['error'] = array("message"=>"Error");
          $this->response($response,REST_Controller::HTTP_NOT_ACCEPTABLE);
    } else {
        $response['message']="Client is Added";
        $response['redirect']="admin/clients";
        $this->response($response,200);
    }
  }
  public function client_delete_get($clientid){
    $clientremove=$this->admin_model->client_remove($clientid);
    if ($clientremove === false) {
      $response['message']="Unable to Removed Client";
      $this->response($response,400);
    } else {
      $response['message']="Client Removed.";
      $response['reload']=1;
      $this->response($response,200);
    }
  }
}
?>
