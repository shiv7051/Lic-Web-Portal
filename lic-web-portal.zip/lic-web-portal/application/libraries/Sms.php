<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sms {
  public function __construct()
  {
    $this->_CI =& get_instance();
    if(file_exists(APPPATH."/config/sms.php")) {
      $this->_CI->load->config('sms');
    }
    //$this->ci->config->item('emails');
    if($this->_CI->config->item('sms_host')){
      $this->sms_host = $this->_CI->config->item('sms_host');
    }
    if($this->_CI->config->item('sms_user')){
      $this->sms_user = $this->_CI->config->item('sms_user');
    }
    if($this->_CI->config->item('sms_pass')){
      $this->sms_pass = $this->_CI->config->item('sms_pass');
    }
    if($this->_CI->config->item('sms_sender')){
      $this->sms_sender = $this->_CI->config->item('sms_sender');
    }
    if($this->_CI->config->item('sms_priority')){
      $this->sms_priority = $this->_CI->config->item('sms_priority');
    }
    if($this->_CI->config->item('sms_type')){
      $this->sms_type = $this->_CI->config->item('sms_type');
    }
  }

  public $error = array("code"=>0,"error"=>"");
  public $mobile = '';
  public $message = '';
  public $sms_host = "http://bulksms.dibc.in/api/sendmsg.php";
  public $sms_del_res_host = "http://bulksms.dibc.in/api/recdlr.php";
  public $sms_user = "";
  public $sms_pass = "";
  public $sms_sender = "DIBC01";
  public $sms_priority = "ndnd";
  public $sms_type = "normal";

  public function send($mobile, $message)
  {
    $this->mobile = $mobile;
    $this->message = $message;
    if($this->sms_user != "" && $this->sms_pass != "" && $this->mobile != "" && $this->message != ""){
      $smsdata = array("user"=>$this->sms_user,
                    "pass"=>$this->sms_pass,
                    "sender"=>$this->sms_sender,
                    "priority"=>$this->sms_priority,
                    "stype"=>$this->sms_type,
                    "phone"=>$this->mobile,
                    "text"=>$this->message,
                    );

		$queryString =  http_build_query($smsdata);
		$msgresult = file_get_contents($this->sms_host . $queryString);
		// echo $this->sms_host . $queryString;
		// print_r($msgresult);
		log_message('info','SMS success '.$this->mobile.' '.$msgresult);
		return $msgresult;
    } else {
      $this->error = array("code"=>1,"error"=>"Unable to initialize - insufficient inputs.");
      log_message('error','SMS failed - insufficient inputs'.$this->mobile);
      return false;
    }
  }
  public function status($msg_id, $mobile){
    //http://bulksms.dibc.in/api/recdlr.php?user=kunjeshnegandhi&msgid=MSGIDOFMESSAGE&phone=9********&msgtype=MessageType
      // $this->mobile = $mobile;
      // $this->message_id = $msg_id;
      if($this->sms_user != "" && $mobile != ""){
        $smsdata = array("user"=>$this->sms_user,
                      "msgtype"=>$this->sms_type,
                      "phone"=>trim($mobile),
                      "msgid"=>trim($msg_id)
                      );

        $queryString =  http_build_query($smsdata);
        // echo ($this->sms_del_res_host ."?". $queryString);
        $msgresult = file_get_contents($this->sms_del_res_host ."?". $queryString);
        // echo $this->sms_host . $queryString;
        // print_r($msgresult);
        // log_message('info','SMS success '.$this->mobile.' '.$msgresult);
        return $msgresult;
      } else {
        // $this->error = array("code"=>1,"error"=>"Unable to initialize - insufficient inputs.");
        // log_message('error','SMS failed - insufficient inputs'.$this->mobile);
        return false;
      }
  }
}
