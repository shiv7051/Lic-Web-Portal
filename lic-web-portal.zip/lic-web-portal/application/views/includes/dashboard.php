<!DOCTYPE html>
<html>
  <head>
    <title>
     My Policy Documents
    </title>
    <style>
    .card {
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
        transition: 0.3s;
        margin-bottom: 20px;
        border-radius: 5px;
        background-image: url('/admin-assets/img/bc.jpeg');
      }
      .card .count {
        height: 100px;
        width: 100px;
        display: inline-block;
        text-align: center;
        line-height: 100px;
        background: #f0f0f0;
        border-radius: 50%;
        box-shadow: 1px 1px 5px #777;
      }
      .card:hover {
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
      }

      img {
        border-radius: 5px 5px 0 0;
      }

      .container {
        padding: 2px 16px;
      }

  </style>
<div class="row">

</div>
