            </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <footer>
      <span class="credits">LIC Agent Web Portal: Designed and Developed by Shiv Shakti.</span>
    </footer>

    <script src="<?php echo base_url(); ?>/admin-assets/js/tinymce/tinymce.min.js"></script>
    <script>


 tinymce.init({
  selector: '.editor',
  plugins: 'image code',
  toolbar: 'undo redo | image code',
  height: 500,
  menubar: true,
  // valid_elements : '*[*]',
     plugins: [
      'advlist autolink lists link image charmap print preview anchor textcolor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code help'
   ],
     toolbar: 'insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
   content_css: [
     '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
      '//www.tinymce.com/css/codepen.min.css'],

       images_upload_url: '<?php echo base_url(); ?>index.php/admin/upload',
       images_upload_base_path: '<?php echo base_url(); ?>uploads/',
       convert_urls: false,
  // we override default upload handler to simulate successful upload
  // images_upload_handler: function (blobInfo, success, failure) {
  //   setTimeout(function() {
  //     // no matter what you upload, we will turn it into TinyMCE logo :)
  //     success('http://moxiecode.cachefly.net/tinymce/v9/images/logo.png');
  //   }, 2000);
  // },

  init_instance_callback: function (ed) {
    ed.execCommand('mceImage');
  }
});
    </script>
    <script class="delete-script-on-load">
       window.baseurl = '<?php echo base_url(); ?>';
      $(document).ready(function(){
        $(this).find('input,textarea,select').addClass('form-control');
        $('.delete-script-on-load').remove();
      });
     </script>
</body>
</html>
