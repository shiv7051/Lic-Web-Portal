<!DOCTYPE html>
<html>
  <head>
    <title>
    LIC web portal
    </title>

    <link href="<?php echo base_url(); ?>admin-assets/css/bootstrap.min.css" media="all" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>admin-assets/css/datatables.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>admin-assets/css/font-awesome.min.css" media="all" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>admin-assets/css/DIBC-cms-admin.css" media="all" rel="stylesheet" type="text/css" />

    <script src="<?php echo base_url(); ?>admin-assets/js/jquery-1.10.2.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>admin-assets/js/popper.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>admin-assets/js/datatables.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>admin-assets/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>admin-assets/js/DIBC_CMS01_Admin_scripts.js" type="text/javascript"></script>

    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
  </head>
  <body class="page-header-fixed bg-1" style="background-color:#71bbfb">
    <div class="modal-shiftfix">
      <!-- Navigation -->
      <div class="navbar navbar-fixed-top scroll-hide" style="background-color:#71bbfb">
        <div class="container-fluid top-bar">
          <div class="pull-right">
            <ul class="nav navbar-nav pull-right">
              <li class="dropdown notifications hidden-xs">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span aria-hidden="true" class="fa fa-flag"></span>
                  <div class="sr-only">
                    Notifications
                  </div>
                  <p class="counter">
                    4
                  </p>
                </a>
                <ul class="dropdown-menu">
                  <!-- <li><a href="#">
                    <div class="notifications label label-info">
                      New
                    </div>
                    <p>
                      New user added:
                    </p></a>

                  </li>
                  <li><a href="#">
                    <div class="notifications label label-info">
                      New
                    </div>
                    <p>
                      Sales targets available
                    </p></a>

                  </li>
                  <li><a href="#">
                    <div class="notifications label label-info">
                      New
                    </div>
                    <p>
                      New performance metric added
                    </p></a>

                  </li>
                  <li><a href="#">
                    <div class="notifications label label-info">
                      New
                    </div>
                    <p>
                      New growth data available
                    </p></a>

                  </li> -->
                </ul>
              </li>
              <li class="dropdown messages hidden-xs">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span aria-hidden="true" class="fa fa-envelope"></span>
                  <div class="sr-only">
                    Messages
                  </div>
                  <p class="counter">
                    3
                  </p>
                </a>
                <ul class="dropdown-menu">
                  <!-- <li><a href="#">
                    <img width="34" height="34" src="images/avatar-male2.png" />Could we meet today? I wanted...</a>
                  </li>
                  <li><a href="#">
                    <img width="34" height="34" src="images/avatar-female.png" />Important data needs your analysis...</a>
                  </li> -->
                </ul>
              </li>
              <li class="dropdown user hidden-xs"><a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <img width="34" height="34" src="<?php echo base_url(); ?>admin-assets/img/shiv.jpg" /><?php echo $admindata->admin_name;?><b class="caret"></b></a>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo base_url()?>admin/change_password">
                    <i class="fa fa-lock"></i>Change Password</a>
                  </li>
                  <li><a href="<?php echo base_url(); ?>web/login">
                    <i class="fa fa-sign-out"></i>Logout</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          <button class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button><a class="logo" href="index.html">Shiv Shakti</a>
        </div>
        <div class="container-fluid main-nav clearfix">
          <div class="nav-collapse">
            <ul class="nav main-nav">
              <?php
          //  if($emprole->emp_role =="superadmin"){
              if(is_array($mainMenu)){
                foreach ($mainMenu as $menuItem){
                  if($menuItem['menu_parent'] == 0){

                    $subMenu = '';
                    foreach ($mainMenu as $subMenuItem) {
                      if($subMenuItem['menu_parent'] == $menuItem['menu_id']){
                        $subMenu .= '<li><i class="'.$subMenuItem['menu_icon'].'"></i><a href="'.base_url().$subMenuItem['menu_link'].'" class="'.$subMenuItem['menu_class'].'">'.$subMenuItem['menu_title'].'</a>';
                      }
                    }
                    if($subMenu != ''){
                      echo '<li class="dropdown"><a data-toggle="dropdown" href="#" class="'.$menuItem['menu_class'].'"><span aria-hidden="true" class="'.$menuItem['menu_icon'].'"></span>'.$menuItem['menu_title'].'<b class="caret"></b></a>';
                      echo '<ul class="dropdown-menu">'.$subMenu.'</ul>';
                    } else {
                      echo '<li class="dropdown"><a href="'.base_url().$menuItem['menu_link'].'" class="'.$menuItem['menu_class'].'"><span aria-hidden="true" class="'.$menuItem['menu_icon'].'"></span>'.$menuItem['menu_title'].'</a>';

                    }
                    echo '</li>';
                  }
                }
              }
          //  }
              ?>
            </ul>
          </div>
        </div>
      </div>
      <!-- End Navigation -->

  <main>
       <div class="container-fluid main-content">
       <h1 class="page-title">
         <?php
          if(isset($page)){
            echo $page['title'];
          }
         ?>
       </h1>
<div class="row">
<div class="col-lg-12">
<div class="widget-container" style="background-color:#71bbfb">
<div class="container content">
