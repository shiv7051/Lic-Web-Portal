<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div style="text-align:right">
 <a href="<?php echo base_url(); ?>index.php/admin/new_client">
   <div class="btn-group">
     <button type="button" class="btn btn-default">New</button>
     </div>
 </a>
</div>
<h1 class="panel-title"></h1><hr>
<table class="table table-hover table-striped item-list">
    <thead>
      <th>Policy No.</th>
      <th>Premium Type</th>
      <th>Name</th>
      <th>Mobile</th>
      <th>DOB</th>
      <th>Occupation</th>
      <th>Address</th>
      <th>Action</th>
    </thead>
    <tbody>
      <?php foreach ($clients as $clientvalue) { ?>
        <tr>
          <td><?php echo $clientvalue->client_policy_no; ?></td>
          <td><?php echo $clientvalue->client_premium_type; ?></td>
          <td><?php echo $clientvalue->client_name; ?></td>
          <td><?php echo $clientvalue->client_mobile; ?></td>
          <td><?php echo $clientvalue->client_dob; ?></td>
          <td><?php echo $clientvalue->client_occupation; ?></td>
          <td><?php echo $clientvalue->client_address; ?></td>
          <td>
          <a href="<?php echo base_url(); ?>index.php/admin/edit_client/<?php echo $clientvalue->client_id; ?>">Edit</a> 
          <!-- <a class="" href="<?php echo base_url(); ?>index.php/admin_api/client_remove/<?php echo $clientvalue->client_id ; ?>">Remove</a> -->
          </td>
        </tr>
        <?php } ?>
  </tbody>
</table>
