<style type="text/css">
 table { border-collapse:collapse; border-spacing:0; empty-cells:show;max-width:215.9mm; }
 td, th { font-size:10pt;padding: 3px}
 h1, h2, h3, h4, h5, h6 { clear:both;}
 ol, ul { margin:0; padding:0;}
 li { list-style: none; margin:0; padding:0;}
 /* "li span.odfLiEnd" - IE 7 issue*/
 .P1 { text-align:left !important; font-size:18pt; }
 .ce1 { vertical-align:middle; border-style:none; text-align:left !important; margin-left:29.9mm; writing-mode:page; color:#2c3b65; font-size:20pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce10 { border-bottom-style:none; border-left-width:0.0261cm; border-left-style:solid; border-left-color:#808080; border-right-width:0.0261cm; border-right-style:solid; border-right-color:#808080; border-top-style:none; text-align:left !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:italic; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce11 { border-bottom-style:none; border-left-width:0.0261cm; border-left-style:solid; border-left-color:#808080; border-right-width:0.0261cm; border-right-style:solid; border-right-color:#808080; border-top-style:none; text-align:left !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:bold; }
 .ce12 { border-bottom-width:0.0261cm; border-bottom-style:solid; border-bottom-color:#808080; border-left-width:0.0261cm; border-left-style:solid; border-left-color:#808080; border-right-width:0.0261cm; border-right-style:solid; border-right-color:#808080; border-top-style:none; text-align:left !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce13 { border-style:none; text-align:center !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce14 { border-style:none; text-align:center !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce15 { border-style:none; text-align:center !important; margin-left:0mm; writing-mode:page; font-size:12pt; font-style:italic; text-shadow:none; text-decoration:none !important; font-weight:bold; }
 .ce17 { margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce2 { font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce28 { background-color:#acbef5;
border-width: 0.0261cm;border-style: solid; border-color:#000000; text-align:center !important; margin-left:0mm; writing-mode:page; color:#000000; font-size:11pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:bold; }
 .ce29 { border-bottom-style:none; background-color:transparent; border-left-width:0.0261cm; border-left-style:solid; border-left-color:#000000; border-right-width:0.0261cm; border-right-style:solid; border-right-color:#000000; border-top-style:none; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce3 { font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce36 { border-bottom-style:none; border-left-width:0.0261cm; border-left-style:solid; border-left-color:#000000; border-right-width:0.0261cm; border-right-style:solid; border-right-color:#000000; border-top-style:none; text-align:center !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce37 { border-bottom-style:none; border-left-style:none; border-right-style:none; border-top-width:0.0261cm; border-top-style:solid; border-top-color:#000000; color:#000000; font-size:11pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce38 { border-style:none; color:#000000; font-size:11pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce39 { font-size:11pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce4 { background-color:#acbef5; border-width:0.0261cm; border-style: solid; border-color:#000000; text-align:left !important; margin-left:0mm; writing-mode:page; color:#000000; font-size:11pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:bold; }
 .ce40 { border-style:none; text-align:right !important; margin-left:0mm; writing-mode:page; color:#7b8ec5; font-size:26pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:bold; }
 .ce41 { background-color:transparent; text-align:right !important; margin-left:5.98mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce46 { border-style:none; text-align:center !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce48 { text-align:right !important; margin-left:0mm; writing-mode:page; color:#7b8ec5; font-size:26pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:bold; }
 .ce49 { background-color:transparent; border-width:0.0261cm; border-style:solid; border-color:#000000; text-align:center !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce5 { border-bottom-style:none; border-left-width:0.0261cm; border-left-style:solid; border-left-color:#000000; border-right-width:0.0261cm; border-right-style:solid; border-right-color:#000000; border-top-style:none; text-align:left !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce50 { border-bottom-width:0.0261cm; border-bottom-style:solid; border-bottom-color:#000000; border-left-width:0.0261cm; border-left-style:solid; border-left-color:#000000; border-right-width:0.0261cm; border-right-style:solid; border-right-color:#000000; border-top-style:none; text-align:center !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce51 { border-bottom-style:none; border-left-width:0.0261cm; border-left-style:solid; border-left-color:#000000; border-right-width:0.0261cm; border-right-style:solid; border-right-color:#000000; border-top-width:0.0261cm; border-top-style:solid; border-top-color:#000000; text-align:center !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce52 { border-width:0.0261cm; border-style:solid; border-color:#000000; text-align:center !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce53 { border-bottom-style:none; background-color:#f2f2f2; border-left-width:0.0261cm; border-left-style:solid; border-left-color:#000000; border-right-width:0.0261cm; border-right-style:solid; border-right-color:#000000; border-top-style:none; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce6 { border-bottom-style:none; border-left-style:none; border-right-style:none; border-top-width:0.0261cm; border-top-style:solid; border-top-color:#000000; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce7 { background-color:#acbef5; border-width:0.0261cm; border-style:solid; border-color:#000000; text-align:left !important; margin-left:0mm; writing-mode:page; color:#000000; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:bold; }
 .ce8 { border-bottom-style:none; border-left-width:0.0261cm; border-left-style:solid; border-left-color:#808080; border-right-width:0.0261cm; border-right-style:solid; border-right-color:#808080; border-top-width:0.0261cm; border-top-style:solid; border-top-color:#acbef5; text-align:left !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ce9 { border-bottom-style:none; border-left-width:0.0261cm; border-left-style:solid; border-left-color:#808080; border-right-width:0.0261cm; border-right-style:solid; border-right-color:#808080; border-top-style:none; text-align:left !important; margin-left:0mm; writing-mode:page; font-size:10pt; font-style:normal; text-shadow:none; text-decoration:none !important; font-weight:normal; }
 .ro1 { height:14.82mm; }
 .ro2 { height:4.52mm; }
 .ro3 { height:4.87mm; }
 .ro4 { height:5.29mm; }
 .item-row td { border-bottom:0.0261cm solid #777;}
</style>

         <table width="100%" border="0" cellspacing="0" cellpadding="0" class="ta1">
            <colgroup>
               <col width="399">
               <col width="85">
               <col width="134">
               <col width="87">
               <col width="105">
               <col width="145">
               <col width="89">
            </colgroup>
            <tbody>
         <?php
         $total=0;
         foreach ($ordproducts as $key => $ordeproduct) {
         $sr = $key+1;
           if($key%20 == 0){
             ?>
             <tr class="ro3">
                <td colspan="2" class="ce4">
                   <p>Code</p>
                </td>
                <td class="ce28">
                  <p>Weight</p>
                </td>
                <td class="ce28">
                   <p>Quantity</p>
                </td>
                <td class="ce28">
                   <p>Category</p>
                </td>
             </tr>
             <?php
           }
           ?>
            <tr class="ro2 item-row">

              <td style="text-align:right; width:30.71mm; " class="ce29">
                 <p><?php echo ($sr%20).'.'.$ordeproduct->prod_code; ?></p>

              </td>
              <td class="ce36">
                 <p><?php echo $ordeproduct->prod_weight; ?></p>
               </td>
              <td class="ce36">
                 <p><?php echo $ordeproduct->quantity; ?></p>
               </td>
              <td class="ce36">
                 <p><?php echo $ordeproduct->cate_title; ?></p>
               </td>
            </tr>
         <?php } ?>
        <tr class="ro3">
            <td class="ce6"> </td>
            <td class="ce6"> </td>
            <td class="ce6"> </td>
            <td class="ce37"></td>
         </tr>
         </tbody>
         </table>
