<div style="text-align:right">
    <a href="<?php echo base_url() ; ?>index.php/admin/clients">
   <div class="btn-group">
     <button type="button" class="btn btn-default">List</button>
     </div>
 </a>
</div>
<h1 class="panel-title"></h1><hr>
<form class="asset_form" action="<?php echo base_url() ; ?>index.php/admin_api/add_client" method="post" role="form" enctype="multipart/form-data">
<div class="row">
 <div class="col-md-4">
   <div class="form-group">
   <label>Name</label>
   <input type="text" name="name"  class="form-control">
 </div>
</div>
 <div class="col-md-4">
   <div class="form-group">
   <label>Mobile</label>
   <input type="number" name="mobile"  class="form-control">
 </div>
</div>
 <div class="col-md-4">
   <div class="form-group">
   <label>DOB</label>
   <input type="date" name="dob"  class="form-control">
 </div>
</div>
</div>
<div class="row">
 <div class="col-md-4">
   <div class="form-group">
   <label>Policy Number</label>
   <input type="number" name="policy_no"  class="form-control">
 </div>
</div>
 <div class="col-md-4">
   <div class="form-group">
   <label>Occupation</label>
   <input type="text" name="occupation"  class="form-control">
 </div>
</div>
 <div class="col-md-4">
   <div class="form-group">
   <label>Premium Type</label>
   <input type="text" name="premium_type"  class="form-control">
 </div>
</div>
</div>
 <div class="row">
 <div class="col-md-12">
   <div class="form-group">
   <label>Address</label>
   <textarea type="text" name="address"  class="form-control"></textarea>
 </div>
</div>
</div>
<input type="submit" value="Submit" class="btn btn-info btn-block">
</form>
