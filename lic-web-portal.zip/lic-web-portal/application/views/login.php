<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html class="no-js h-100" lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo isset($title)?$title:"LIC Web Portal"; ?></title>
    <meta name="description" content="Powered by DIBC">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<style>
    /* body {
        background: url(https://demo.dibc.in/vishal-saldanha/machine-maintenance/assets/images/ShelfDrilling.jpg) #bad6e1 no-repeat;
        background-size: 100% auto;
        background-position: bottom;
        height: 100vh;
        width: 100vw;
    }
    p,a {
        color: #fff;
    }
 */

</style>
  </head>
  <body class="h-100">
    <div class="container-fluid">
          <div class="row">
            <div class="col-md-4"></div>

    <div class="col-md-4">
      <section class="login-form text-center" style="background: rgba(255,255,255,0.75);box-shadow: 5px 5px 10px #000; border-radius:25px; padding:25px; margin-top:50px">
        <div>
      <span class="text-danger"><?php echo @$_GET['error']; ?></span>
    </div>
        <form method="post" action="<?php echo base_url(); ?>web/login_post" role="login">
          <input type="username" name="username" placeholder="User Name" required autofocus class="form-control input-lg" value="" />
          <br>
          <input type="password" class="form-control input-lg" name="password" placeholder="Password" required="" />
          <br>


          <div class="pwstrength_viewport_progress"></div>


          <button type="submit" name="go" class="btn btn-lg btn-primary btn-block">Sign in</button>
          <div>
            <!-- <a href="#">Create account</a> or <a href="#">reset password</a> -->
          </div>

        </form>

        <div class="form-links">
          <a href="#"></a>
        </div>
      </section>
      </div>

      <div class="col-md-4"></div>


          </div>
      </div>

      <div class="copyrights" style="position:fixed; bottom:0;text-align:center; width:100%">
        <p>
          Designed & Developed by <a href="http://dibc.in/" target="_blank">DIBC</a>
          <?php echo ($this->config->item('site_title'))?' for '.$this->config->item('site_title'):''; ?>
           © All rights reserved
           <?php echo date('Y'); ?>
        </p>
      </div>
    </body>
  </html>
