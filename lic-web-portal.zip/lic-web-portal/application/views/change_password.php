<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html class="no-js h-100" lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo isset($title)?$title:"DIBC Admin"; ?></title>
    <meta name="description" content="Powered by DIBC">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
  </head>
  <body class="h-100">
    <div class="container-fluid">
          <div class="row">
            <div class="col-md-4"></div>

    <div class="col-md-4">
      <section class="login-form text-center" style="background:#fff; border-radius:25px; padding:25px; margin-top:50px">
        <div>
      <span class="text-danger"><?php echo @$_GET['error']; ?></span>
      </div>
        <form method="post" action="<?php echo base_url();?>admin_api/change_password" role="login">
          <input type="password" name="old_password" placeholder="Old Password" required autofocus class="form-control" value="" />
          <br>
          <input type="password" class="form-control" name="new_password" placeholder="New Password" required="" />
          <br>
          <input type="password" class="form-control" name="conf_password" placeholder="Conform Password" required="" />
          <br>


          <div class="pwstrength_viewport_progress"></div>


          <button type="submit" name="go" class="btn btn-lg btn-primary btn-block">Submit</button>
          <div>
            <!-- <a href="#">Create account</a> or <a href="#">reset password</a> -->
          </div>

        </form>

        <div class="form-links">
          <a href="#"></a>
        </div>
      </section>
      </div>

      <div class="col-md-4"></div>


          </div>
      </div>

    </body>
  </html>
