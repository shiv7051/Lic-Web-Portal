<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Email Config
|--------------------------------------------------------------------------
|
*/
$config['sms_host'] = 'http://bulksms.dibc.in/api/sendmsg.php?';
$config['sms_user'] = 'dibctest';
$config['sms_pass'] = 'DIBC@19';
$config['sms_sender'] = 'DIBCTA';
$config['sms_priority'] = 'ndnd';
$config['sms_type'] = 'normal';
