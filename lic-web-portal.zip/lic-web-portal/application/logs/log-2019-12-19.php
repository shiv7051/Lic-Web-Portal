<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-19 22:50:58 --> 404 Page Not Found: Admin-assets/images
ERROR - 2019-12-19 22:51:04 --> 404 Page Not Found: Admin-assets/images
ERROR - 2019-12-19 22:51:36 --> Severity: error --> Exception: syntax error, unexpected 'client_reset_otp' (T_STRING), expecting function (T_FUNCTION) C:\xampp\htdocs\myjewellery-api\application\models\app-models\App_model.php 53
ERROR - 2019-12-19 22:52:03 --> Severity: error --> Exception: syntax error, unexpected 'client_reset_otp' (T_STRING), expecting function (T_FUNCTION) C:\xampp\htdocs\myjewellery-api\application\models\app-models\App_model.php 53
ERROR - 2019-12-19 23:03:07 --> Severity: Notice --> Undefined variable: registerdata C:\xampp\htdocs\myjewellery-api\application\controllers\App-api\App_api.php 92
ERROR - 2019-12-19 23:03:07 --> SMS failed - insufficient inputs
