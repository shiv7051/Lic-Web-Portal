<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-03 11:39:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'aniljewellery' C:\xampp\htdocs\myjewellery-api\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-12-03 11:39:06 --> Unable to connect to the database
ERROR - 2019-12-03 11:39:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'aniljewellery' C:\xampp\htdocs\myjewellery-api\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-12-03 11:39:06 --> Unable to connect to the database
ERROR - 2019-12-03 12:40:49 --> Query error: Table 'jewel.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `user_mobile` = '9920073732'
 LIMIT 1
ERROR - 2019-12-03 13:11:22 --> Severity: error --> Exception: Call to undefined method App_model::client_register() C:\xampp\htdocs\myjewellery-api\application\controllers\App-api\App_api.php 51
ERROR - 2019-12-03 13:46:03 --> Query error: Table 'jewel.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `user_mobile` = '9920073732'
 LIMIT 1
ERROR - 2019-12-03 13:46:36 --> Severity: error --> Exception: Call to undefined method App_model::client_register() C:\xampp\htdocs\myjewellery-api\application\controllers\App-api\App_api.php 53
ERROR - 2019-12-03 13:47:38 --> Query error: Table 'jewel.users' doesn't exist - Invalid query: INSERT INTO `users` (`client_name`, `client_mobile`, `client_city`, `client_bussiness_type`, `client_company_name`, `client_address`, `client_otp`) VALUES ('kunjesh', '9920073732', 'mum', 'test', 'test company', 'abcd\nabab', '07031')
