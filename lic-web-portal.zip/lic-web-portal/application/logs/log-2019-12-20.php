<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-20 00:08:18 --> Severity: error --> Exception: Call to undefined method App_model::get_client() C:\xampp\htdocs\myjewellery-api\application\controllers\App-api\App_api.php 19
ERROR - 2019-12-20 00:08:29 --> Severity: error --> Exception: Call to undefined method App_model::get_client() C:\xampp\htdocs\myjewellery-api\application\controllers\App-api\App_api.php 19
ERROR - 2019-12-20 00:08:51 --> Severity: error --> Exception: Call to undefined method App_model::get_client() C:\xampp\htdocs\myjewellery-api\application\controllers\App-api\App_api.php 19
ERROR - 2019-12-20 00:09:15 --> Severity: error --> Exception: Call to undefined method App_model::get_client() C:\xampp\htdocs\myjewellery-api\application\controllers\App-api\App_api.php 19
ERROR - 2019-12-20 16:35:35 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:35:35 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:35:35 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:35:36 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:35:36 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:35:36 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:35:36 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:39:15 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:39:15 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:39:15 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:39:15 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:39:15 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:39:15 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:39:15 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:47:29 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:47:29 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:47:29 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:47:29 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:47:29 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:47:29 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 16:47:29 --> 404 Page Not Found: Uploads/small
ERROR - 2019-12-20 22:04:23 --> 404 Page Not Found: Admin-assets/images
ERROR - 2019-12-20 22:04:29 --> 404 Page Not Found: Admin-assets/images
ERROR - 2019-12-20 22:04:33 --> 404 Page Not Found: Admin-assets/images
ERROR - 2019-12-20 22:05:13 --> 404 Page Not Found: Admin-assets/images
