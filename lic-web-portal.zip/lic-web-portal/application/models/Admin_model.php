<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {
    public function __construct() {
  	   parent::__construct();
       // $this->output->enable_profiler(true);
    }
public function menuList(){
  $this->db->select('*')
            ->from('admin_menu')
            ->where('menu_status',1);
          $query=$this->db->get();
          return $query->result_array();
}
public function get_admin($adminname){
    $this->db->select('*')
              ->from('admin')
              ->where('admin_name',$adminname);
              $query=$this->db->get();
              return $query->row();
  }
  public function admin_data($adminid){
      $this->db->select('*')
                ->from('admin')
                ->where('admin_id',$adminid);
                $query=$this->db->get();
                return $query->row();
    }
    public function change_password($data){
        $this->db->select('admin_password');
        $this->db->from('admin');
        $this->db->where('admin_id', $data['admin_id']);
        $admin=$this->db->get();
        $admindata = $admin->row_array();

        $adminpassword = $admindata['admin_password'];

        if(password_verify($data['admin_old_pwd'],$adminpassword)){

          unset($data['admin_old_pwd']);
          $data['admin_password'] = password_hash($data['admin_password'], PASSWORD_DEFAULT);
          $this->db->where('admin_id',$data['admin_id']);
          if($this->db->update('admin',$data)){
            return true;
          } else {
            return false;
          }
        } else {
          return false;
         }
    }
public function client_insert($clientdata){
      if($this->db->insert('clients',$clientdata)){
        return $this->db->insert_id();
      }else {
        return false;
      }
  }
public function get_clients(){
  $this->db->select('*')
            ->from('clients')
            ->where('client_status',1);
            $query=$this->db->get();
            return $query->result();
  }
public function get_client($id){
  $this->db->select('*,')
            ->from('clients')
            ->where('client_id',$id);
            $query=$this->db->get();
            return $query->row();
  }
public function client_update($clientdata,$clientid){
        $this->db->where('client_id',$clientid);
        return $this->db->update('clients',$clientdata);
  }
public function client_remove($clientid){
    $this->db->set('client_status',0);
    $this->db->where('client_id',$clientid);
    if($this->db->update('clients')){
      return true;
    }else {
      return false;
    }
  }
}
?>
